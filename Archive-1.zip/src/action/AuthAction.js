import {LOGIN_STATUS,LOGOUT_STATUS} from "./Status" 

export const PaymentAction=(data)=>{
	console.log(data)
	return async(dispatch)=>{
		dispatch({type:LOGIN_STATUS.LOGIN_REQUEST}) 
			dispatch({
				type:LOGIN_STATUS.LOGIN_SUCCESS,
				payload:{
					data
				}
			})
 
	}
}
 