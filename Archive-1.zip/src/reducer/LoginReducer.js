import {LOGIN_STATUS,LOGOUT_STATUS} from '../action/Status';

const initialData = {
	user:[]

};

export default (state=initialData,action)=>{
	 
	 switch(action.type){

	 	case LOGIN_STATUS.LOGIN_REQUEST:
	 	    state={
	 	    	...state,
	 	    	authenticating:true,
	 	    	loading:true
	 	    }
	 	break;
	 	case LOGIN_STATUS.LOGIN_SUCCESS:
	 	     state={
	 	     	...state,  
	 	     	wishlist:action.payload.data

	 	     }
	 	break; 
	 	
	}
	 return state;
}
