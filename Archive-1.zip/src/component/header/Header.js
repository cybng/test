import React,{useState} from 'react'
import { Link } from 'react-router-dom'

export default function Header() {

    const [isChatOpen, setIsChatopen] = useState(false);
    const [isChatBoxOpen, setIsChatBoxopen] = useState(false);
    const [isNotificationOpen, setIsNotificationopen] = useState(false);

    const chatBoxSidebar = () => {
        isChatBoxOpen === true ? setIsChatBoxopen(false) : setIsChatBoxopen(true);

    }
 	const chatSidebar = () => {
        isChatOpen === true ? setIsChatopen(false) : setIsChatopen(true);
    }
 	const notificationBar = () => {
        isNotificationOpen === true ? setIsNotificationopen(false) : setIsNotificationopen(true);
    }
	return (
		<div>
		<header className="fixed flex w-full lbg  border-b border-gray-100 text-white text-sm justify-between items-center py-3">
		    <div className="container mx-auto flex justify-between items-center">
			<div className="font-normal text-xl w-9/12 flex items-center  text-left space-x-2">
				<Link to={"/"} className="font-semibold  bg-white px-2 rounded-sm txt">it</Link>
				<div className="w-10/12 flex">
				<input type="text" className=" border-b border-gray-100 w-full rounded-tl-sm rounded-bl-sm text-sm px-2 py-1 font-thin text-black" placeholder="Search"/>
				<button className="bg-gray-100 px-5 text-gray-400 rounded-tr-sm rounded-br-sm">
					<svg xmlns="http://www.w3.org/2000/svg" className="icon icon-tabler icon-tabler-search" width={18} height={18} viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round">
        <path stroke="none" d="M0 0h24v24H0z" fill="none" />
        <circle cx={10} cy={10} r={7} />
        <line x1={21} y1={21} x2={15} y2={15} />
      </svg>
				</button></div>
			</div>
			<div className="flex space-x-8">
			{/*<p>Home</p> */}
				<Link to={"/task"}><svg xmlns="http://www.w3.org/2000/svg" className="icon icon-tabler icon-tabler-list-details" width={20} height={20} viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round">
        <path stroke="none" d="M0 0h24v24H0z" fill="none" />
        <path d="M13 5h8" />
        <path d="M13 9h5" />
        <path d="M13 15h8" />
        <path d="M13 19h5" />
        <rect x={3} y={4} width={6} height={6} rx={1} />
        <rect x={3} y={14} width={6} height={6} rx={1} />
      </svg></Link>
				<p onClick={chatSidebar}><svg xmlns="http://www.w3.org/2000/svg" className="icon icon-tabler icon-tabler-message-code" width={20} height={20} viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round">
        <path stroke="none" d="M0 0h24v24H0z" fill="none" />
        <path d="M4 21v-13a3 3 0 0 1 3 -3h10a3 3 0 0 1 3 3v6a3 3 0 0 1 -3 3h-9l-4 4" />
        <path d="M10 9l-2 2l2 2" />
        <path d="M14 9l2 2l-2 2" />
      </svg></p>
				<p onClick={notificationBar}><svg xmlns="http://www.w3.org/2000/svg" className="icon icon-tabler icon-tabler-bell-ringing" width={20} height={20} viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round">
        <path stroke="none" d="M0 0h24v24H0z" fill="none" />
        <path d="M10 5a2 2 0 0 1 4 0a7 7 0 0 1 4 6v3a4 4 0 0 0 2 3h-16a4 4 0 0 0 2 -3v-3a7 7 0 0 1 4 -6" />
        <path d="M9 17v1a3 3 0 0 0 6 0v-1" />
        <path d="M21 6.727a11.05 11.05 0 0 0 -2.794 -3.727" />
        <path d="M3 6.727a11.05 11.05 0 0 1 2.792 -3.727" />
      </svg></p>
				<p><svg xmlns="http://www.w3.org/2000/svg" className="icon icon-tabler icon-tabler-user-circle" width={20} height={20} viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" fill="none" strokeLinecap="round" strokeLinejoin="round">
        <path stroke="none" d="M0 0h24v24H0z" fill="none" />
        <circle cx={12} cy={12} r={9} />
        <circle cx={12} cy={10} r={3} />
        <path d="M6.168 18.849a4 4 0 0 1 3.832 -2.849h4a4 4 0 0 1 3.834 2.855" />
      </svg></p>
			</div>
			</div>
		</header>





		<div className="">
                 <div className={`sidebar w-3/12 text-left px-3 py-2 ${isChatOpen == true ? 'active' : ''}`}>
                   <div className="flex-row text-left border-b border-gray-100">
					<p className="txt pt-2 text-lg">Messaging</p>
					<p className="text-gray-400 text-xs pt-1 pb-2">Contact with your client</p>
					</div>
					<div className="text-gray-500 text-sm py-2">
					<p>Online </p>
					<div className="flex justify-start items-center space-x-2 border-b border-gray-100 py-2" onClick={chatBoxSidebar}>
						<img src="https://avatars.githubusercontent.com/u/49819046?s=400&u=5c5367992d575d939a5b950a6b5925a12e7afe26&v=4" className="h-12 w-12 rounded-full p-0.5 border-2 border-green-800"/>
						<div className="flex-row">
						<p className="txt text-sm">Alenno Miza</p>
						<p className="text-gray-400 text-xs">Make a social website </p>
						</div>
					</div>
					<div className="flex justify-start items-center space-x-2 border-b border-gray-100 py-2">
						<img src="https://avatars.githubusercontent.com/u/49819046?s=400&u=5c5367992d575d939a5b950a6b5925a12e7afe26&v=4" className="h-12 w-12 rounded-full p-0.5 border-2 border-green-800"/>
						<div className="flex-row">
						<p className="txt text-sm">Maxmine Lia</p>
						<p className="text-gray-400 text-xs">project Name</p>
						</div>
					</div>
					<div className="flex justify-start items-center space-x-2 border-b border-gray-100 py-2">
						<img src="https://avatars.githubusercontent.com/u/49819046?s=400&u=5c5367992d575d939a5b950a6b5925a12e7afe26&v=4" className="h-12 w-12 rounded-full p-0.5 border-2 border-green-800"/>
						<div className="flex-row">
						<p className="txt text-sm">Likion jaice</p>
						<p className="text-gray-400 text-xs">Live streaming project</p>
						</div>
					</div>
					</div>
					<div className="text-gray-500 text-sm h-32 py-2">
					<p>Offline </p>
					<div className="flex justify-start items-center space-x-2 border-b border-gray-100 py-2">
						<img src="https://avatars.githubusercontent.com/u/49819046?s=400&u=5c5367992d575d939a5b950a6b5925a12e7afe26&v=4" className="h-12 w-12 rounded-full p-0.5 border-2 border-gray-200"/>
						<div className="flex-row">
						<p className="txt text-sm">Zikko za</p>
						<p className="text-gray-400 text-xs">Make a social website </p>
						</div>
					</div>
					<div className="flex justify-start items-center space-x-2 border-b border-gray-100 py-2">
						<img src="https://avatars.githubusercontent.com/u/49819046?s=400&u=5c5367992d575d939a5b950a6b5925a12e7afe26&v=4" className="h-12 w-12 rounded-full p-0.5 border-2 border-gray-200"/>
						<div className="flex-row">
						<p className="txt text-sm">Finel Nia</p>
						<p className="text-gray-400 text-xs">project Name</p>
						</div>
					</div>
					<div className="flex justify-start items-center space-x-2 border-b border-gray-100 py-2">
						<img src="https://avatars.githubusercontent.com/u/49819046?s=400&u=5c5367992d575d939a5b950a6b5925a12e7afe26&v=4" className="h-12 w-12 rounded-full p-0.5 border-2 border-gray-200"/>
						<div className="flex-row">
						<p className="txt text-sm">Xixion xuchi</p>
						<p className="text-gray-400 text-xs">Live streaming project</p>
						</div>
					</div>
					</div>

					 
                          
                    </div>
                    <div className={`sidebar-overlay ${isChatOpen == true ? 'active' : ''}`} onClick={chatSidebar}></div>
           </div>


				<div className="">
                 
                    <div className={`sidebar w-3/12 text-left px-3 py-2 ${isChatBoxOpen == true ? 'active' : ''}`}>
                   <div className="flex-row text-left border-b border-gray-100">
					<p className="flex justify-start txt pt-2 text-lg items-center"> Alenno Miza</p>
					<p className="text-gray-400 text-xs pt-1 pb-2">Last time online 4:10 pm</p>
					</div>
					<div className="h-screen">
				 	<div className="h-4/6">
					<textarea className="text-gray-500 text-sm py-2 border border-gray-300 rounded-sm w-full h-full resize-none">
					 
					</textarea>
					<div className="flex justify-between items-center">
					<input type="text" className="p-2 border border-gray-300 text-sm rounded-sm  w-full" placeholder="Send Messages"/>
					<button className="p-2 lbg rounded-sm text-white text-sm">send </button>
					</div>
			 		</div>
					</div>
					</div>
                    <div className={`sidebar-overlayx ${isChatBoxOpen == true ? 'active' : ''}`} onClick={chatBoxSidebar}></div>
           </div>



       {/*NOTIFICATIONS*/}
       <div className="">
                 <div className={`sidebar w-3/12 text-left px-3 py-2 ${isNotificationOpen == true ? 'active' : ''}`}>
                   <div className="flex-row text-left border-b border-gray-100">
					<p className="txt pt-2 text-lg">Notifications</p>
					{/*<p className="text-gray-400 text-xs pt-1 pb-2">See Old Notifications</p>*/}
					</div>
					<div className="text-gray-500 text-sm py-2">
					<div className="flex-col justify-start border-b border-gray-100 py-2">
						<p className="txt text-sm">Alenno Miza</p>
						<p className="text-gray-400 text-xs py-1">Congratulations Your Project Accepted  </p>
						<p className="text-gray-400 text-xs">10/10/2022 2:00 pm   </p>
					</div> 
					<div className="flex-col justify-start border-b border-gray-100 py-2">
						<p className="text-md">Social Media Project</p>
						<p className="text-gray-400 text-xs py-1">Sorry Your Project Rejected  </p>
						<p className="text-gray-400 text-xs">10/10/2022 2:00 pm   </p>
					</div>

					</div>

					 
                          
                    </div>
                    <div className={`sidebar-overlay ${isNotificationOpen == true ? 'active' : ''}`} onClick={notificationBar}></div>
           </div>
			
		</div>
	)
}