import React,{useState } from 'react'
import { Link } from 'react-router-dom' 
import {PaymentAction} from "../action"
import {useDispatch,useSelector} from "react-redux"


export default function Home() {

const [name,setName] = useState("")
const [amount,setAmount] = useState("")
const dispatch = useDispatch();
const wishlist = useSelector(state=>state?.login?.wishlist);

const payment=()=>{
	const data = {name:name,amount:amount}
	console.log(wishlist)
	if(wishlist){
		wishlist?.push(data);
	dispatch(PaymentAction(wishlist));
	}else {
      let array = [];
      array.push(data);
      dispatch(PaymentAction(array))
    }
}


	return (
		<div className="flex bg-gray-100 mt-10 w-full justify-center items-center">
		<div className="flex-col">
		<input type="text" onChange={(e)=>setName(e.target.value)}/>
		<br/>
		<br/>
		<input type="text" onChange={(e)=>setAmount(e.target.value)} />
		<br/>
		<br/>
		<button onClick={(e)=>payment()}> payment</button>
		</div>
	 	
		</div>
	)
}